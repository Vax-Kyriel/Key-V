function Set-Gen1BootDisk([string]$Name, [int]$Number) {
    $ide = @(Get-VMHardDiskDrive -VMName $Name -ControllerType IDE)
    $dvds = @(Get-VMDvdDrive -VMName $Name)
    $used = @{}
    foreach ($d in $ide) {
        $used["$($d.ControllerNumber):$($d.ControllerLocation)"] = $d
    }
    foreach ($d in $dvds) {
        $used["$($d.ControllerNumber):$($d.ControllerLocation)"] = 'dvd'
    }

    $slot00 = $used['0:0']
    if ($null -eq $slot00) {
        Add-VMHardDiskDrive -VMName $Name -ControllerType IDE -ControllerNumber 0 -ControllerLocation 0 -DiskNumber $Number
        return
    }
    if ($slot00 -eq 'dvd') { throw 'IDE_DVD' }
    if ($null -ne $slot00.DiskNumber) { throw 'IDE_PHYSICAL' }
    if ([string]::IsNullOrWhiteSpace([string]$slot00.Path)) { throw 'IDE_FULL' }

    $free = $null
    $pairs = @(
        ,@(0, 1)
        ,@(1, 0)
        ,@(1, 1)
    )
    foreach ($pair in $pairs) {
        $key = "$($pair[0]):$($pair[1])"
        if (-not $used.ContainsKey($key)) {
            $free = $pair
            break
        }
    }
    if ($null -eq $free) { throw 'IDE_FULL' }

    $vhdPath = [string]$slot00.Path
    $slot = "$($free[0]):$($free[1])"
    Remove-VMHardDiskDrive -VMName $Name -ControllerType IDE -ControllerNumber 0 -ControllerLocation 0
    try {
        Add-VMHardDiskDrive -VMName $Name -ControllerType IDE -ControllerNumber 0 -ControllerLocation 0 -DiskNumber $Number
    } catch {
        try {
            Add-VMHardDiskDrive -VMName $Name -ControllerType IDE -ControllerNumber 0 -ControllerLocation 0 -Path $vhdPath
        } catch { }
        throw
    }
    try {
        Add-VMHardDiskDrive -VMName $Name -ControllerType IDE -ControllerNumber $free[0] -ControllerLocation $free[1] -Path $vhdPath
        Emit ('LOG' + $t + 'MOVED_VHD' + $t + $slot + $t + $vhdPath)
    } catch {
        Emit ('LOG' + $t + 'VHD_REATTACH_FAIL' + $t + $vhdPath)
    }
}

$prevSb = $null
$prevTemplate = $null
try {
    Require-HyperV
    if ($env:KEYV_DISK -notmatch '^\d+$') { Fail 'BAD_DISK' }
    $diskNumber = [int]$env:KEYV_DISK
    $vmName = $env:KEYV_VM
    $vm = Get-KeyVVm $vmName
    $disk = Assert-UsbDisk $diskNumber

    if ($vm.State -ne 'Off') { Fail 'VM_NOT_OFF' }
    if ($vm.Generation -eq 2 -and [string]$disk.PartitionStyle -ne 'GPT') { Fail 'NOT_GPT' }

    $owners = New-Object System.Collections.Generic.List[string]
    foreach ($other in @(Get-VM)) {
        foreach ($drive in @(Get-VMHardDiskDrive -VMName $other.Name)) {
            if ($drive.DiskNumber -eq $diskNumber) { [void]$owners.Add([string]$other.Name) }
        }
    }
    if ($owners.Count -gt 0) { Fail ('ALREADY_ATTACHED' + $t + ($owners -join ', ')) }

    Emit ('LOG' + $t + 'OFFLINE')
    Set-UsbOffline $diskNumber

    $added = $false
    try {
        if ($vm.Generation -eq 2) {
            Add-VMHardDiskDrive -VMName $vmName -ControllerType SCSI -ControllerNumber 0 -DiskNumber $diskNumber
            $added = $true
            $drive = @(Get-VMHardDiskDrive -VMName $vmName | Where-Object { $_.DiskNumber -eq $diskNumber }) | Select-Object -First 1
            if ($null -eq $drive) { throw 'NOT_ADDED' }
            if ($env:KEYV_DISABLE_SB -eq '1') {
                $fw = Get-VMFirmware -VMName $vmName
                $sb = [string]$fw.SecureBoot
                $template = ([string]$fw.SecureBootTemplate).Replace([char]9, ' ')
                Emit ('PREVSB' + $t + $sb + $t + $template)
                if ($sb -eq 'On') {
                    $prevSb = $sb
                    $prevTemplate = $template
                    Set-VMFirmware -VMName $vmName -EnableSecureBoot Off
                    Emit ('LOG' + $t + 'SB_OFF')
                }
            }
            Set-VMFirmware -VMName $vmName -FirstBootDevice $drive
            Emit ('LOG' + $t + 'ATTACHED_SCSI')
        } else {
            Set-Gen1BootDisk $vmName $diskNumber
            $added = $true
            Set-VMBios -VMName $vmName -StartupOrder @('IDE', 'CD', 'LegacyNetworkAdapter', 'Floppy')
            Emit ('LOG' + $t + 'ATTACHED_IDE')
        }
    } catch {
        if ($prevSb -eq 'On') {
            $tpl = $prevTemplate
            if ([string]::IsNullOrWhiteSpace($tpl)) { $tpl = 'MicrosoftWindows' }
            try { Set-VMFirmware -VMName $vmName -EnableSecureBoot On -SecureBootTemplate $tpl } catch { }
        }
        if ($added) {
            Get-VMHardDiskDrive -VMName $vmName | Where-Object { $_.DiskNumber -eq $diskNumber } | Remove-VMHardDiskDrive
        }
        Set-UsbOnline $diskNumber | Out-Null
        $m = $_.Exception.Message
        if ($m -match 'denied|refus') { Fail 'ACCESS_DENIED' }
        Fail $m
    }

    Emit ('LOG' + $t + 'CHECKPOINT')
    if ($env:KEYV_START -eq '1') {
        try {
            Start-VM -Name $vmName
            Emit ('LOG' + $t + 'VM_STARTED')
            Open-KeyVConsole $vmName
        } catch {
            $detail = $_.Exception.Message.Replace([char]9, ' ').Replace([char]10, ' ').Replace([char]13, ' ')
            Emit ('LOG' + $t + 'START_FAIL' + $t + $detail)
        }
    }
    Emit 'OK'
} catch {
    $m = $_.Exception.Message
    if ($m -match 'denied|refus') { Fail 'ACCESS_DENIED' }
    Fail $m
}
