$ErrorActionPreference = 'Stop'
$t = [char]9

function Emit([string]$line) {
    $enc = New-Object System.Text.UTF8Encoding $false
    [System.IO.File]::AppendAllText($env:KEYV_OUT, ($line + [Environment]::NewLine), $enc)
}

function Fail([string]$msg) {
    if ($null -eq $msg) { $msg = 'Erreur inconnue.' }
    $clean = $msg.Replace("`r", ' ').Replace("`n", ' ')
    Emit ('ERR' + $t + $clean)
    exit 1
}

function Require-HyperV {
    $vmms = Get-Service -Name vmms -ErrorAction SilentlyContinue
    if ($null -eq $vmms) { Fail 'NO_HYPERV' }
    if ($vmms.Status -ne 'Running') { Fail 'HYPERV_STOPPED' }
    Import-Module Hyper-V -ErrorAction Stop
}

function Get-KeyVVm([string]$vmName) {
    if ([string]::IsNullOrWhiteSpace($vmName)) { Fail 'NO_VM' }
    return Get-VM -Name $vmName
}

function Assert-UsbDisk([int]$diskNumber) {
    $disk = Get-Disk -Number $diskNumber
    if ($disk.BusType -ne 'USB') { Fail 'NOT_USB' }
    if ($disk.IsBoot -or $disk.IsSystem) { Fail 'IS_SYSTEM' }
    return $disk
}

function Set-UsbOffline([int]$diskNumber) {
    $disk = Get-Disk -Number $diskNumber
    try {
        if ($disk.IsReadOnly) {
            Set-Disk -Number $diskNumber -IsReadOnly $false
        }
        if (-not $disk.IsOffline) {
            Set-Disk -Number $diskNumber -IsOffline $true
        }
    } catch {
        $m = $_.Exception.Message
        if ($m -match 'in use|being used|utilis|autre processus') { Fail 'IN_USE' }
        if ($m -match 'denied|refus') { Fail 'ACCESS_DENIED' }
        Fail $m
    }
    Start-Sleep -Milliseconds 400
}

function Set-UsbOnline([int]$diskNumber) {
    try {
        Set-Disk -Number $diskNumber -IsOffline $false
        return $true
    } catch {
        return $false
    }
}

function Open-KeyVConsole([string]$vmName) {
    $vmconnect = Join-Path (Join-Path $env:SystemRoot 'System32') 'vmconnect.exe'
    if (-not (Test-Path -LiteralPath $vmconnect)) {
        Emit ('LOG' + $t + 'NO_VMCONNECT')
        return
    }
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $vmconnect
    $psi.Arguments = 'localhost "' + ($vmName -replace '"', '') + '"'
    $psi.UseShellExecute = $true
    [void][System.Diagnostics.Process]::Start($psi)
    Emit ('LOG' + $t + 'CONSOLE_OPENED')
}
