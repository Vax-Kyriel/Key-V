@echo off
setlocal
cd /d "%~dp0"
set "JAVA_HOME="
for /d %%D in ("%ProgramFiles%\Microsoft\jdk-*") do set "JAVA_HOME=%%D"
if not defined JAVA_HOME (
  for /d %%D in ("%LocalAppData%\Programs\Microsoft\jdk-*") do set "JAVA_HOME=%%D"
)
if not defined JAVA_HOME (
  echo JDK 21 introuvable. Installe Microsoft OpenJDK 21, puis relance run.bat.
  exit /b 1
)
if not exist build mkdir build
"%JAVA_HOME%\bin\javac.exe" --release 21 -encoding UTF-8 -d build src\keyv\*.java
if errorlevel 1 exit /b 1
start "" "%JAVA_HOME%\bin\javaw.exe" -cp build keyv.KeyVApp
